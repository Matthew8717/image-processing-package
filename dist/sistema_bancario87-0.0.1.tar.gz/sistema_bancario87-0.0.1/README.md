# package_name

Description. 
The package sistema_bancario is used to:
	banco: 
		-Fins educativos sem utilidades reais.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install sistema_bancario

```bash
pip install sistema_bancario
```

## Usage

```python
from sistema_bancario.banco import banco
banco.teste("Hello World!")
```

## Author
Matthew Henry 

## License
[MIT](https://choosealicense.com/licenses/mit/)